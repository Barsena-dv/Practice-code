// Function to show the selected tab (login or signup)
function showTab(tab) {
    const loginForm = document.getElementById('loginForm');
    const signupForm = document.getElementById('signupForm');
    const loginButton = document.querySelector('.tab-button.active');
    const signupButton = document.querySelector('.tab-button:not(.active)');
  
    if (tab === 'login') {
      loginForm.classList.add('active');
      signupForm.classList.remove('active');
      loginButton.classList.add('active');
      signupButton.classList.remove('active');
    } else {
      signupForm.classList.add('active');
      loginForm.classList.remove('active');
      signupButton.classList.add('active');
      loginButton.classList.remove('active');
    }
  }
  
  // Handle Login Form Submission
  document.getElementById('loginForm').addEventListener('submit', function(event) {
    event.preventDefault();
  
    const email = document.getElementById('loginEmail').value;
    const password = document.getElementById('loginPassword').value;
  
    // TODO: Validate credentials by sending to backend
  
    // For now, assuming login is successful
    alert('Login Successful');
    window.location.href = 'dashboard.html'; // Redirect to dashboard after login
  });
  
  // Handle Sign Up Form Submission
  document.getElementById('signupForm').addEventListener('submit', function(event) {
    event.preventDefault();
  
    const fullName = document.getElementById('fullName').value;
    const email = document.getElementById('signupEmail').value;
    const password = document.getElementById('signupPassword').value;
    const confirmPassword = document.getElementById('confirmPassword').value;
  
    // Basic validation
    if (password !== confirmPassword) {
      alert('Passwords do not match');
      return;
    }
  
    // TODO: Send data to backend for processing
  
    alert('Sign Up Successful');
    window.location.href = 'login.html'; // Redirect to login page after sign up
  });
  