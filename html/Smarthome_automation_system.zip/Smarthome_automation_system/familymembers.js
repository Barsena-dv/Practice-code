document.getElementById('familyMembersForm').addEventListener('submit', function(event) {
    event.preventDefault();
  
    // Get the input values
    const fullName = document.getElementById('fullName').value;
    const age = document.getElementById('age').value;
    const relationship = document.getElementById('relationship').value;
    const contactNumber = document.getElementById('contactNumber').value;
  
    // Create a new list item
    const listItem = document.createElement('li');
    listItem.textContent = `${fullName}, Age: ${age}, Relationship: ${relationship}, Contact: ${contactNumber}`;
  
    // Append the new family member to the list
    document.getElementById('membersList').appendChild(listItem);
  
    // Clear the input fields
    document.getElementById('familyMembersForm').reset();
  });
  