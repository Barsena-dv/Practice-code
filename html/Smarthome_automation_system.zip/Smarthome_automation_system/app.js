// js/app.js

document.addEventListener('DOMContentLoaded', () => {
  loadDevices();
  loadScenes();
  setupSettingsForm();
  setupAddSceneButton();
});

// Function to load devices and render them
function loadDevices() {
  fetchDevices()
    .then(devices => {
      const deviceGrid = document.getElementById('deviceGrid');
      deviceGrid.innerHTML = ''; // Clear existing devices
      devices.forEach(device => {
        const deviceCard = createDeviceCard(device);
        deviceGrid.appendChild(deviceCard);
      });
    })
    .catch(error => console.error('Error loading devices:', error));
}

// Function to create a device card element
function createDeviceCard(device) {
  const card = document.createElement('div');
  card.className = 'device-card';

  const img = document.createElement('img');
  img.src = getDeviceIcon(device.type);
  img.alt = `${device.type} icon`;

  const title = document.createElement('h3');
  title.textContent = device.name;

  const status = document.createElement('p');
  status.textContent = `Status: ${device.status ? 'On' : 'Off'}`;

  const toggleBtn = document.createElement('button');
  toggleBtn.textContent = device.status ? 'Turn Off' : 'Turn On';
  toggleBtn.addEventListener('click', () => toggleDevice(device.id));

  card.appendChild(img);
  card.appendChild(title);
  card.appendChild(status);
  card.appendChild(toggleBtn);

  return card;
}

// Function to get device icon based on type
function getDeviceIcon(type) {
  switch(type) {
    case 'light':
      return 'assets/images/light.png';
    case 'thermostat':
      return 'assets/images/thermostat.png';
    case 'camera':
      return 'assets/images/camera.png';
    default:
      return 'assets/images/device.png';
  }
}

// Function to toggle device status
function toggleDevice(deviceId) {
  toggleDeviceStatus(deviceId)
    .then(updatedDevice => {
      loadDevices();
      addNotification(`${updatedDevice.name} turned ${updatedDevice.status ? 'On' : 'Off'}.`);
    })
    .catch(error => console.error('Error toggling device:', error));
}

// Function to load scenes and render them
function loadScenes() {
  fetchScenes()
    .then(scenes => {
      const scenesGrid = document.getElementById('scenesGrid');
      scenesGrid.innerHTML = ''; // Clear existing scenes
      scenes.forEach(scene => {
        const sceneCard = createSceneCard(scene);
        scenesGrid.appendChild(sceneCard);
      });
    })
    .catch(error => console.error('Error loading scenes:', error));
}

// Function to create a scene card element
function createSceneCard(scene) {
  const card = document.createElement('div');
  card.className = 'scene-card';

  const img = document.createElement('img');
  img.src = 'assets/images/scene.png'; // Placeholder icon for scenes
  img.alt = `Scene icon`;

  const title = document.createElement('h3');
  title.textContent = scene.name;

  const activateBtn = document.createElement('button');
  activateBtn.textContent = 'Activate';
  activateBtn.addEventListener('click', () => activateScene(scene.id));

  card.appendChild(img);
  card.appendChild(title);
  card.appendChild(activateBtn);

  return card;
}

// Function to activate a scene
function activateScene(sceneId) {
  activateSceneAPI(sceneId)
    .then(result => {
      addNotification(`Scene "${result.name}" activated.`);
      loadDevices(); // Refresh device statuses
    })
    .catch(error => console.error('Error activating scene:', error));
}

// Function to set up the settings form
function setupSettingsForm() {
  const settingsForm = document.getElementById('settingsForm');
  settingsForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const username = settingsForm.username.value;
    const password = settingsForm.password.value;

    updateSettings({ username, password })
      .then(result => {
        addNotification('Settings updated successfully.');
        settingsForm.reset();
      })
      .catch(error => console.error('Error updating settings:', error));
  });
}

// Function to set up the Add Scene button
function setupAddSceneButton() {
  const addSceneBtn = document.getElementById('addSceneBtn');
  addSceneBtn.addEventListener('click', () => {
    const sceneName = prompt('Enter the name of the new scene:');
    if (sceneName) {
      createScene(sceneName)
        .then(newScene => {
          addNotification(`Scene "${newScene.name}" added.`);
          loadScenes();
        })
        .catch(error => console.error('Error adding scene:', error));
    }
  });
}

// Function to add a notification to the notification list
function addNotification(message) {
  const notificationList = document.getElementById('notificationList');
  const notificationItem = document.createElement('li');
  notificationItem.textContent = message;
  notificationList.prepend(notificationItem);

  // Optionally, remove the notification after some time
  setTimeout(() => {
    notificationList.removeChild(notificationItem);
  }, 5000);
}
