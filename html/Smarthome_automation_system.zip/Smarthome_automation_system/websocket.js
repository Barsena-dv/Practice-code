// js/websocket.js

let socket;

function initializeWebSocket() {
  socket = new WebSocket("wss://your-backend-websocket-url"); // Replace with your WebSocket URL

  socket.onopen = () => {
    console.log("WebSocket connection established.");
    // Optionally, authenticate or subscribe to specific channels
  };

  socket.onmessage = (event) => {
    const data = JSON.parse(event.data);
    handleWebSocketMessage(data);
  };

  socket.onclose = () => {
    console.log("WebSocket connection closed. Reconnecting in 5 seconds...");
    setTimeout(initializeWebSocket, 5000); // Attempt to reconnect after 5 seconds
  };

  socket.onerror = (error) => {
    console.error("WebSocket error:", error);
    socket.close();
  };
}

function handleWebSocketMessage(data) {
  switch (data.type) {
    case "DEVICE_STATUS_UPDATE":
      updateDeviceCard(data.device);
      addNotification(
        `${data.device.name} status updated to ${
          data.device.status ? "On" : "Off"
        }.`
      );
      break;
    case "NEW_NOTIFICATION":
      addNotification(data.message);
      break;
    // Add more cases as needed
    default:
      console.warn("Unhandled WebSocket message type:", data.type);
  }
}

function updateDeviceCard(device) {
  // Find the device card and update its status
  const deviceCards = document.querySelectorAll(".device-card");
  deviceCards.forEach((card) => {
    const title = card.querySelector("h3").textContent;
    if (title === device.name) {
      const statusText = card.querySelector("p");
      statusText.textContent = `Status: ${device.status ? "On" : "Off"}`;

      const toggleBtn = card.querySelector("button");
      toggleBtn.textContent = device.status ? "Turn Off" : "Turn On";
    }
  });
}

// Initialize WebSocket when the app starts
document.addEventListener("DOMContentLoaded", initializeWebSocket);
