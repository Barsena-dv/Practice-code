document.addEventListener('DOMContentLoaded', function() {
    const notificationList = document.getElementById('notificationList');
  
    // Example notifications (you can replace this with actual data)
    const notifications = [
      { message: 'Smoke detected in the kitchen', time: '10:45 AM' },
      { message: 'Front door left open', time: '9:15 AM' },
      { message: 'Living room lights turned on', time: '8:30 AM' },
      { message: 'Motion detected in backyard', time: '8:00 AM' }
    ];
  
    // Function to render notifications
    function renderNotifications() {
      notificationList.innerHTML = ''; // Clear current list
      notifications.forEach(notification => {
        const notificationItem = document.createElement('div');
        notificationItem.classList.add('notification-item');
        notificationItem.innerHTML = `
          <p>${notification.message}</p>
          <span class="notification-time">${notification.time}</span>
        `;
        notificationList.appendChild(notificationItem);
      });
    }
  
    // Initial rendering of notifications
    renderNotifications();
  
    // Clear all notifications
    document.getElementById('clearNotificationsBtn').addEventListener('click', function() {
      notifications.length = 0; // Clear the notifications array
      renderNotifications(); // Re-render the list
      alert('All notifications cleared!');
    });
  });
  