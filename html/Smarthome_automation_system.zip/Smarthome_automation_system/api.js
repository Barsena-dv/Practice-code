// js/api.js

// Base API URL
const API_BASE_URL = "https://api.yoursmarthome.com"; // Replace with your backend API URL

// Function to fetch devices
function fetchDevices() {
  return fetch(`${API_BASE_URL}/devices`)
    .then((response) => response.json())
    .catch((error) => console.error("Error fetching devices:", error));
}

// Function to toggle device status
function toggleDeviceStatus(deviceId) {
  return fetch(`${API_BASE_URL}/devices/${deviceId}/toggle`, {
    method: "POST",
  })
    .then((response) => response.json())
    .catch((error) => console.error("Error toggling device:", error));
}

// Function to fetch scenes
function fetchScenes() {
  return fetch(`${API_BASE_URL}/scenes`)
    .then((response) => response.json())
    .catch((error) => console.error("Error fetching scenes:", error));
}

// Function to create a new scene
function createScene(sceneName) {
  return fetch(`${API_BASE_URL}/scenes`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ name: sceneName }),
  })
    .then((response) => response.json())
    .catch((error) => console.error("Error creating scene:", error));
}

// Function to activate a scene
function activateSceneAPI(sceneId) {
  return fetch(`${API_BASE_URL}/scenes/${sceneId}/activate`, {
    method: "POST",
  })
    .then((response) => response.json())
    .catch((error) => console.error("Error activating scene:", error));
}

// Function to update settings
function updateSettings(settings) {
  return fetch(`${API_BASE_URL}/settings`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(settings),
  })
    .then((response) => response.json())
    .catch((error) => console.error("Error updating settings:", error));
}
