// js/app.js

document.addEventListener('DOMContentLoaded', () => {
    loadExpenses();
    loadFamilyMembers();
    setupSettingsForm();
    setupAddExpenseButton();
    setupAddFamilyMemberButton();
  });
  
  // Function to load expenses from the API and render them
  function loadExpenses() {
    fetch('/api/expenses') // Replace with your actual API endpoint
      .then(response => response.json())
      .then(expenses => {
        const expenseList = document.getElementById('expenseList');
        expenseList.innerHTML = ''; // Clear existing expenses
        let totalExpenses = 0;
        expenses.forEach(expense => {
          totalExpenses += expense.amount;
          const expenseItem = createExpenseItem(expense);
          expenseList.appendChild(expenseItem);
        });
        document.getElementById('totalExpenses').textContent = `$${totalExpenses}`;
      })
      .catch(error => console.error('Error fetching expenses:', error));
  }
  
  // Function to create an expense item element
  function createExpenseItem(expense) {
    const item = document.createElement('div');
    item.className = 'expense-item';
  
    const title = document.createElement('h3');
    title.textContent = expense.description;
  
    const amount = document.createElement('p');
    amount.textContent = `$${expense.amount} (${expense.category})`;
  
    const editBtn = document.createElement('button');
    editBtn.textContent = 'Edit';
    editBtn.addEventListener('click', () => editExpense(expense));
  
    const deleteBtn = document.createElement('button');
    deleteBtn.textContent = 'Delete';
    deleteBtn.addEventListener('click', () => deleteExpense(expense.id));
  
    item.appendChild(title);
    item.appendChild(amount);
    item.appendChild(editBtn);
    item.appendChild(deleteBtn);
  
    return item;
  }
  
  // Function to add a new expense
  function setupAddExpenseButton() {
    const addExpenseBtn = document.getElementById('addExpenseBtn');
    addExpenseBtn.addEventListener('click', () => {
      const description = prompt('Enter expense description:');
      const amount = parseFloat(prompt('Enter amount:'));
      const category = prompt('Enter category:');
      if (description && amount && category) {
        fetch('/api/expenses', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ description, amount, category })
        })
          .then(response => response.json())
          .then(newExpense => {
            loadExpenses();
          })
          .catch(error => console.error('Error adding expense:', error));
      }
    });
  }
  
  // Function to edit an expense
  function editExpense(expense) {
    const newDescription = prompt('Edit description:', expense.description);
    const newAmount = parseFloat(prompt('Edit amount:', expense.amount));
    const newCategory = prompt('Edit category:', expense.category);
    if (newDescription && newAmount && newCategory) {
      fetch(`/api/expenses/${expense.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ description: newDescription, amount: newAmount, category: newCategory })
      })
        .then(() => {
          loadExpenses();
        })
        .catch(error => console.error('Error updating expense:', error));
    }
  }
  
  // Function to delete an expense
  function deleteExpense(expenseId) {
    if (confirm('Are you sure you want to delete this expense?')) {
      fetch(`/api/expenses/${expenseId}`, { method: 'DELETE' })
        .then(() => {
          loadExpenses();
        })
        .catch(error => console.error('Error deleting expense:', error));
    }
  }
  
  // Load Family Members
  function loadFamilyMembers() {
    fetch('/api/family')
      .then(response => response.json())
      .then(familyMembers => {
        const familyList = document.getElementById('familyList');
        familyList.innerHTML = '';
        familyMembers.forEach(member => {
          const memberItem = createFamilyMemberItem(member);
          familyList.appendChild(memberItem);
        });
        document.getElementById('familyMembersCount').textContent = familyMembers.length;
      })
      .catch(error => console.error('Error fetching family members:', error));
  }
  
  // Create Family Member Item
  function createFamilyMemberItem(member) {
    const item = document.createElement('div');
    item.className = 'family-member-item';
  
    const name = document.createElement('h3');
    name.textContent = member.name;
  
    const age = document.createElement('p');
    age.textContent = `Age: ${member.age}`;
  
    const editBtn = document.createElement('button');
    editBtn.textContent = 'Edit';
    editBtn.addEventListener('click', () => editFamilyMember(member));
  
    const deleteBtn = document.createElement('button');
    deleteBtn.textContent = 'Delete';
    deleteBtn.addEventListener('click', () => deleteFamilyMember(member.id));
  
    item.appendChild(name);
    item.appendChild(age);
    item.appendChild(editBtn);
    item.appendChild(deleteBtn);
  
    return item;
  }
  
  // Add new family member
  function setupAddFamilyMemberButton() {
    const addFamilyMemberBtn = document.getElementById('addFamilyMemberBtn');
    addFamilyMemberBtn.addEventListener('click', () => {
      const name = prompt('Enter family member name:');
      const age = parseInt(prompt('Enter age:'));
      if (name && age) {
        fetch('/api/family', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ name, age })
        })
          .then(response => response.json())
          .then(newMember => {
            loadFamilyMembers();
          })
          .catch(error => console.error('Error adding family member:', error));
      }
    });
  }
  
  // Edit Family Member
  function editFamilyMember(member) {
    const newName = prompt('Edit name:', member.name);
    const newAge = parseInt(prompt('Edit age:', member.age));
    if (newName && newAge) {
      fetch(`/api/family/${member.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: newName, age: newAge })
      })
        .then(() => {
          loadFamilyMembers();
        })
        .catch(error => console.error('Error updating family member:', error));
    }
  }
  
  // Delete Family Member
  function deleteFamilyMember(memberId) {
    if (confirm('Are you sure you want to delete this family member?')) {
      fetch(`/api/family/${memberId}`, { method: 'DELETE' })
        .then(() => {
          loadFamilyMembers();
        })
        .catch(error => console.error('Error deleting family member:', error));
    }
  }
  
  // Settings form handler
  function setupSettingsForm() {
    const settingsForm = document.getElementById('settingsForm');
    settingsForm.addEventListener('submit', (event) => {
      event.preventDefault();
      const budget = document.getElementById('budget').value;
      const currency = document.getElementById('currency').value;
      fetch('/api/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ budget, currency })
      })
        .then(response => response.json())
        .then(settings => {
          alert('Settings updated!');
        })
        .catch(error => console.error('Error updating settings:', error));
    });
  }
  // Handle Expense Form Submission
document.getElementById('expenseForm').addEventListener('submit', function(event) {
    event.preventDefault();
  
    const expenseName = document.getElementById('expenseName').value;
    const expenseAmount = document.getElementById('expenseAmount').value;
    const expenseCategory = document.getElementById('expenseCategory').value;
  
    // Process and display the new expense
    addExpense(expenseName, expenseAmount, expenseCategory);
  });
  
  function addExpense(name, amount, category) {
    const expenseList = document.getElementById('expenseList');
    const newExpense = document.createElement('div');
    newExpense.classList.add('expense-item');
    newExpense.innerHTML = `<p>${name}: $${amount} (${category})</p>`;
    expenseList.appendChild(newExpense);
  
    // Update total expenses or other logic
  }
  
  // Handle Family Member Form Submission
  document.getElementById('familyMemberForm').addEventListener('submit', function(event) {
    event.preventDefault();
  
    const memberName = document.getElementById('memberName').value;
    const memberRelation = document.getElementById('memberRelation').value;
    const memberAge = document.getElementById('memberAge').value;
  
    // Process and display the new family member
    addFamilyMember(memberName, memberRelation, memberAge);
  });
  
  function addFamilyMember(name, relation, age) {
    const familyList = document.getElementById('familyList');
    const newMember = document.createElement('div');
    newMember.classList.add('family-member');
    newMember.innerHTML = `<p>${name} (${relation}), Age: ${age}</p>`;
    familyList.appendChild(newMember);
  
    // Update family member count or other logic
  }
  