document.getElementById('settingsForm').addEventListener('submit', function(event) {
    event.preventDefault();
  
    const theme = document.getElementById('theme').value;
    const language = document.getElementById('language').value;
    const deviceName = document.getElementById('deviceName').value;
    const timezone = document.getElementById('timezone').value;
    const securityCode = document.getElementById('securityCode').value;
    const twoFactorAuth = document.getElementById('twoFactorAuth').checked;
    const powerSavingMode = document.getElementById('powerSavingMode').checked;
  
    // Simulate saving the settings (replace this with actual API calls)
    console.log('Settings saved:');
    console.log('Theme:', theme);
    console.log('Language:', language);
    console.log('Device Name:', deviceName);
    console.log('Timezone:', timezone);
    console.log('Security Code:', securityCode);
    console.log('Two-Factor Authentication:', twoFactorAuth);
    console.log('Power Saving Mode:', powerSavingMode);
  
    alert('Settings saved successfully!');
  });
  